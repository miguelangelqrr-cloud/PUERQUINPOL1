PUERQUINPOL — proyecto Android + compilación automática

Este proyecto incluye: juego HTML autocontenido, WebView Android y servidor WebSocket local integrado para multijugador por Wi‑Fi.

Compilación automática con GitHub Actions:
1. Crea un repositorio en GitHub.
2. Sube TODO el contenido de esta carpeta (no solo el ZIP).
3. En GitHub abre Actions → Build PUERQUINPOL APK → Run workflow.
4. Espera a que termine.
5. Abre la ejecución terminada y descarga el artefacto PUERQUINPOL-debug-apk.
6. Dentro encontrarás app-debug.apk.

También puedes compilar localmente con Android Studio usando Gradle 8.2.x y JDK 17.

Multijugador Wi‑Fi:
- Instala la misma APK en los dos teléfonos.
- Conecta ambos a la misma red Wi‑Fi.
- En el anfitrión selecciona “2 jugadores — Wi‑Fi local”, deja vacía la IP y pulsa Conectar.
- En el segundo teléfono escribe la IP que muestra el anfitrión y pulsa Conectar.
- El servidor local integrado usa el puerto 8787.
- No se necesita Internet durante la partida; la compilación sí necesita descargar dependencias la primera vez.
