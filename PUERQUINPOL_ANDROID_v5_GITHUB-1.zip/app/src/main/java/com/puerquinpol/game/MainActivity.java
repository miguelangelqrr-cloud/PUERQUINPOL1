package com.puerquinpol.game;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.net.*;
import java.util.*;

public class MainActivity extends Activity {
    private WebView webView;
    private LanServer server;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                String ip = getWifiIp();
                view.evaluateJavascript("(function(){var e=document.getElementById('localIp');if(e)e.textContent=" + jsQuote(ip) + ";})()", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);

        server = new LanServer(this);
        server.start();
        loadGameWhenServerReady(0);
    }

    private void loadGameWhenServerReady(int attempt) {
        if (isFinishing() || webView == null) return;
        if (server != null && server.isReady()) {
            webView.loadUrl("http://127.0.0.1:" + LanServer.PORT + "/index.html");
            return;
        }
        if (attempt >= 60) {
            Toast.makeText(this, "No se pudo iniciar el servidor local.", Toast.LENGTH_LONG).show();
            return;
        }
        handler.postDelayed(() -> loadGameWhenServerReady(attempt + 1), 50);
    }

    @Override protected void onResume() { super.onResume(); }

    @Override protected void onDestroy() {
        if (server != null) server.stop();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private String jsQuote(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    private String getWifiIp() {
        try {
            List<NetworkInterface> list = Collections.list(NetworkInterface.getNetworkInterfaces());
            // Prefer the usual Wi-Fi interfaces so a cellular/VPN address is not shown to the player.
            list.sort((a,b) -> Boolean.compare(!a.getName().toLowerCase(Locale.US).contains("wlan"),
                                                !b.getName().toLowerCase(Locale.US).contains("wlan")));
            for (NetworkInterface ni : list) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress() && !a.isLinkLocalAddress()) {
                        return a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {}
        return "No disponible";
    }
}
