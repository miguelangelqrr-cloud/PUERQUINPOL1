package com.puerquinpol.game;

import android.content.Context;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import android.util.Base64;

/** Tiny dependency-free HTTP + WebSocket server for the local Wi-Fi multiplayer mode. */
public class LanServer {
    public static final int PORT = 8787;
    private final Context context;
    private final List<Client> clients = new CopyOnWriteArrayList<>();
    private volatile boolean running;
    private ServerSocket serverSocket;
    private Thread acceptThread;

    public LanServer(Context context) { this.context = context.getApplicationContext(); }

    public boolean isReady() {
        return running && serverSocket != null && !serverSocket.isClosed() && serverSocket.isBound();
    }

    public void start() {
        if (running) return;
        running = true;
        acceptThread = new Thread(() -> {
            try {
                serverSocket = new ServerSocket();
                serverSocket.setReuseAddress(true);
                serverSocket.bind(new InetSocketAddress(PORT));
                while (running) {
                    Socket socket = serverSocket.accept();
                    new Thread(() -> handle(socket), "pp-client").start();
                }
            } catch (IOException ignored) {
            } finally { running = false; }
        }, "pp-server");
        acceptThread.start();
    }

    public void stop() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
        for (Client c : clients) c.close();
        clients.clear();
    }

    private void handle(Socket socket) {
        Client c = null;
        try {
            socket.setTcpNoDelay(true);
            socket.setSoTimeout(0);
            BufferedInputStream in = new BufferedInputStream(socket.getInputStream());
            OutputStream out = socket.getOutputStream();
            String request = readHttpHeaders(in);
            if (request == null) { socket.close(); return; }
            String first = request.split("\\r?\\n", 2)[0];
            boolean upgrade = request.toLowerCase(Locale.US).contains("upgrade: websocket");
            if (upgrade) {
                String key = header(request, "Sec-WebSocket-Key");
                if (key == null) { socket.close(); return; }
                String accept = Base64.encodeToString(MessageDigest.getInstance("SHA-1")
                        .digest((key.trim() + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.US_ASCII)), Base64.NO_WRAP);
                String response = "HTTP/1.1 101 Switching Protocols\r\n" +
                        "Upgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + accept + "\r\n\r\n";
                out.write(response.getBytes(StandardCharsets.US_ASCII)); out.flush();
                c = new Client(socket, in, out);
                synchronized (clients) {
                    if (clients.size() >= 2) { c.sendText("{\"type\":\"full\"}"); c.close(); return; }
                    clients.add(c);
                    boolean oneTaken = false, twoTaken = false;
                    for (Client existing : clients) {
                        if (existing == c) continue;
                        if (existing.role == 1) oneTaken = true;
                        if (existing.role == 2) twoTaken = true;
                    }
                    c.role = !oneTaken ? 1 : (!twoTaken ? 2 : 1);
                }
                c.sendText("{\"type\":\"role\",\"role\":" + c.role + "}");
                if (clients.size() == 2) broadcast("{\"type\":\"peer\"}");
                while (running && !c.closed) {
                    String msg = readFrame(c.in);
                    if (msg == null) break;
                    if (msg.startsWith("\"")) continue;
                    if (msg.contains("\"type\":\"input\"")) {
                        for (Client other : clients) if (other != c) other.sendText(msg);
                    }
                }
            } else {
                // Serve the bundled game to WebView / browser.
                String path = "/";
                String[] bits = first.split(" ");
                if (bits.length >= 2) path = bits[1];
                if (path.equals("/") || path.startsWith("/index.html")) {
                    byte[] html = readAsset("index.html");
                    String head = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + html.length + "\r\nConnection: close\r\n\r\n";
                    out.write(head.getBytes(StandardCharsets.US_ASCII)); out.write(html); out.flush();
                } else {
                    byte[] body = "Not found".getBytes(StandardCharsets.UTF_8);
                    String head = "HTTP/1.1 404 Not Found\r\nContent-Length: " + body.length + "\r\nConnection: close\r\n\r\n";
                    out.write(head.getBytes(StandardCharsets.US_ASCII)); out.write(body); out.flush();
                }
                socket.close();
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) {
                clients.remove(c);
                if (!clients.isEmpty()) broadcast("{\"type\":\"peer_left\"}");
            }
            try { socket.close(); } catch (Exception ignored) {}
        }
    }

    private byte[] readAsset(String name) throws IOException {
        try (InputStream is = context.getAssets().open(name); ByteArrayOutputStream b = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n; while ((n=is.read(buf))!=-1) b.write(buf,0,n); return b.toByteArray();
        }
    }

    private void broadcast(String msg) { for (Client c : clients) c.sendText(msg); }

    private static String readHttpHeaders(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int state = 0;
        int x;
        while ((x = in.read()) != -1) {
            b.write(x);
            if (state == 0 && x == '\r') state = 1;
            else if (state == 1 && x == '\n') state = 2;
            else if (state == 2 && x == '\r') state = 3;
            else if (state == 3 && x == '\n') {
                break;
            } else state = 0;
            if (b.size() > 32768) throw new IOException("headers too large");
        }
        return b.toString(StandardCharsets.ISO_8859_1.name());
    }

    private static String header(String request, String wanted) {
        for (String line : request.split("\\r?\\n")) {
            int p=line.indexOf(':'); if(p>0 && line.substring(0,p).trim().equalsIgnoreCase(wanted)) return line.substring(p+1).trim();
        } return null;
    }

    private static String readFrame(InputStream in) throws IOException {
        int b1=in.read(), b2=in.read(); if(b1<0||b2<0) return null;
        int opcode=b1&0x0F; boolean masked=(b2&0x80)!=0; long len=b2&0x7F;
        if(len==126){len=((in.read()&255)<<8)|(in.read()&255);} else if(len==127){len=0;for(int i=0;i<8;i++)len=(len<<8)|(in.read()&255);}
        if(len>65536) throw new IOException("frame too large");
        byte[] mask=masked?new byte[4]:null; if(mask!=null) readFully(in,mask);
        byte[] data=new byte[(int)len]; readFully(in,data); if(masked)for(int i=0;i<data.length;i++)data[i]=(byte)(data[i]^mask[i%4]);
        if(opcode==8) return null;
        if(opcode==9) return ""; // ignore ping payload; browsers normally manage this internally
        if(opcode!=1) return "";
        return new String(data,StandardCharsets.UTF_8);
    }
    private static void readFully(InputStream in, byte[] b) throws IOException { int p=0,n;while(p<b.length&&(n=in.read(b,p,b.length-p))>0)p+=n;if(p<b.length)throw new EOFException(); }

    private static class Client {
        final Socket socket; final InputStream in; final OutputStream out; volatile boolean closed; int role;
        Client(Socket s, InputStream i, OutputStream o){socket=s;in=i;out=o;}
        synchronized void sendText(String text){if(closed)return;try{byte[] d=text.getBytes(StandardCharsets.UTF_8);ByteArrayOutputStream f=new ByteArrayOutputStream();f.write(0x81);if(d.length<126){f.write(d.length);}else{f.write(126);f.write((d.length>>>8)&255);f.write(d.length&255);}f.write(d);out.write(f.toByteArray());out.flush();}catch(Exception e){close();}}
        void close(){closed=true;try{socket.close();}catch(Exception ignored){}}
    }
}
